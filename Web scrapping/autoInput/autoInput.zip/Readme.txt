Set screen size 1920*1080
You should login and click Watchlist
And follow video

*Detail
First, you should login and click Watchlist
Second, run the program and activate that web browser within 3 seconds

***
you shouldn't work until finish the data input